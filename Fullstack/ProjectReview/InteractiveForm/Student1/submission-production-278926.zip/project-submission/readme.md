# Interactive Form

**Interactive Form** 
A client side form validation made with JQuery.

## Video Walkthrough

<img src='https://github.com/allan9595/interactive-form-v1-treehouseTech/blob/master/form-validation.gif' title='Video Walkthrough' width='' alt='Video Walkthrough' />

GIF created with [LiceCap](http://www.cockos.com/licecap/).


## License

    Copyright 2019 BOHAN ZHANG
